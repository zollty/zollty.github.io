package test;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Date;

public class HomeServlet extends HttpServlet {

   public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
      
	  String text = null;
	  HttpSession session = request.getSession();
	  Date logonDate = null;
	  if (session != null) {
	     text = (String) session.getAttribute("NAME");
		 logonDate = (Date) session.getAttribute("TIME");
      }
	  
	  
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
	  
      out.println("<html>");
      out.println("<body>");
	  out.println("<h1>Logged-on User: " + text + "</h1>");
	  out.println("<h2>Logon Time: " + logonDate + "</h2>");
      out.println("</body>");
      out.println("</html>");
   }

}