package test;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class TestServlet extends HttpServlet {

   private int count = 0;

   public void init()
          throws ServletException {
	System.out.println("---------------TestServlet starts working.......------------------");
	System.out.println("---------------Path = "+this.getInitParameter("path"));
	System.out.println("---------------Encoding = "+this.getServletContext().getInitParameter("encoding"));
   }

   public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
      
	  String text = request.getParameter("name");
      if (text == null)
         text = "World";
	  
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
	  
      out.println("<html>");
      out.println("<body>");
      out.println("<h1>Hello " + text + "</h1>");
	  count++;
	  out.println("<h3>Count = " + count + "</h3>");
	  
	  out.println("<h3>IE? - " + isIE(request) + "</h3>");

	  String path = this.getInitParameter("path");
	  out.println("<h3>Init Parameter - Path = " + path + "</h3>");
      out.println("</body>");
      out.println("</html>");
   }
   
   
   protected boolean isIE(HttpServletRequest request) throws IOException {
      String agentHeader = request.getHeader("User-Agent");
	  if( agentHeader!=null && agentHeader.indexOf("MSIE")!=-1 ){
	      return true;
	  }
      return false;
   }
   
   
   public void destroy() {
   
     System.out.println("---------------TestServlet stopped.......------------------");
    
   }

}