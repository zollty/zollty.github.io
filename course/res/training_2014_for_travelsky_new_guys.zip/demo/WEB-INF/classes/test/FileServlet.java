package test;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FileServlet extends HttpServlet {

   public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
      
	  //final String filePath = "D:/logo_login.jpg";
      //response.setContentType("image/jpeg");
	  
	  final String filePath = "D:/logo_login.zip";
	  response.setContentType("application/x-zip-compressed");
	  response.addHeader("Content-Disposition", "attachment; filename=" + "logo_login.zip"); 
	  
      OutputStream out = null;
	  InputStream in = null;
	  
	  try{
		  in = new FileInputStream(filePath);
		  out = response.getOutputStream();
		  
		  int numRead = 0;
		  byte[] buf = new byte[1024];
		  while (-1 != (numRead = in.read(buf))) {
			out.write(buf, 0, numRead);
		  }
		  out.flush();
		  
	  } finally {
          closeIO(in, out);
	  }
      
   }
   
   
    public final static void closeIO(InputStream in, OutputStream out) {
        if (null != in) {
            try {
                in.close();
            } catch (IOException e) {}
        }
		if (null != out) {
            try {
                out.close();
            } catch (IOException e) {}
        }
    }

}