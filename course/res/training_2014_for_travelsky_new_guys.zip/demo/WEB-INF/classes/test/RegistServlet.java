package test;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Date;

public class RegistServlet extends HttpServlet {

   public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	  
      response.setContentType("text/html;charset=utf-8");
      PrintWriter out = response.getWriter();
	  
	  out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<body>");
	  out.println("<header>");
	  out.println("<meta http-equiv=content-type content=text/html;charset=utf-8>");
	  out.println("</header>");
	  
	  out.println("<h1>�û�ע��</h1>");
	  out.println("<form action='post.do' method='post'>");
	  
	  out.println("&emsp;�û�����<input type='text' name='name' value='' /><br/>");
	  out.println("&emsp;&emsp;���룺<input type='text' name='passwd' value='' /><br/>");
	  out.println("ȷ�����룺<input type='text' name='rpasswd' value='' /><br/>");
	  out.println("�����ַ��<input type='text' name='email' value='' /><br/><br/>");
	  out.println("&emsp;&emsp;&emsp;&emsp;<input type='submit' value='ע��' />");
	  out.println("</form>");
      out.println("</body>");
      out.println("</html>");
   }

}